// ===== Canvas Setup =====
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight * 0.6;
}
resizeCanvas();
window.addEventListener("resize", resizeCanvas);

// ===== Game State =====
let player = { x: 100, y: 0, w: 40, h: 20, speed: 6 };
let bullets = [];
let enemies = [];
let particles = [];

let score = 0;
let level = 1;
let bulletsLeft = 10;
let bestLevel = localStorage.getItem("bestLevel") || 1;

let running = true;
let gameOver = false;

// ===== UI =====
const scoreEl = document.getElementById("score");
const levelEl = document.getElementById("level");
const bulletsEl = document.getElementById("bullets");
const bestEl = document.getElementById("best");
bestEl.textContent = bestLevel;

// ===== Controls =====
let moveLeft = false;
let moveRight = false;

// Buttons
document.getElementById("leftBtn").ontouchstart = () => moveLeft = true;
document.getElementById("leftBtn").ontouchend = () => moveLeft = false;

document.getElementById("rightBtn").ontouchstart = () => moveRight = true;
document.getElementById("rightBtn").ontouchend = () => moveRight = false;

document.getElementById("shootBtn").onclick = shoot;

// Keyboard
document.addEventListener("keydown", e => {
  if (e.key === "ArrowLeft" || e.key === "a") moveLeft = true;
  if (e.key === "ArrowRight" || e.key === "d") moveRight = true;
  if (e.key === " ") shoot();
  if (e.key === "p" || e.key === "Escape") togglePause();
});

document.addEventListener("keyup", e => {
  if (e.key === "ArrowLeft" || e.key === "a") moveLeft = false;
  if (e.key === "ArrowRight" || e.key === "d") moveRight = false;
});

// ===== Shooting =====
function shoot() {
  if (!running || bulletsLeft <= 0) return;
  bullets.push({ x: player.x + player.w/2, y: player.y });
  bulletsLeft--;
}

// ===== Enemy Spawn =====
function spawnEnemy() {
  let isBomb = Math.random() < 0.2;
  enemies.push({
    x: Math.random() * canvas.width,
    y: -20,
    size: 20,
    speed: 1 + level * 0.5,
    bomb: isBomb
  });
}

// ===== Particles =====
function createParticles(x, y, color) {
  for (let i = 0; i < 10; i++) {
    particles.push({
      x, y,
      dx: (Math.random()-0.5)*4,
      dy: (Math.random()-0.5)*4,
      life: 30,
      color
    });
  }
}

// ===== Game Loop =====
function update() {
  if (!running || gameOver) return;

  // Player
  player.y = canvas.height - 30;
  if (moveLeft) player.x -= player.speed;
  if (moveRight) player.x += player.speed;
  player.x = Math.max(0, Math.min(canvas.width - player.w, player.x));

  // Bullets
  bullets.forEach(b => b.y -= 8);

  // Enemies
  if (Math.random() < 0.02 + level*0.005) spawnEnemy();
  enemies.forEach(e => e.y += e.speed);

  // Collisions
  bullets.forEach((b, bi) => {
    enemies.forEach((e, ei) => {
      if (b.x < e.x+e.size && b.x > e.x &&
          b.y < e.y+e.size && b.y > e.y) {

        if (e.bomb) {
          createParticles(e.x, e.y, "orange");
          lose();
        } else {
          let pts = 1 + (level-1)*5;
          score += pts;
          createParticles(e.x, e.y, "red");
        }

        bullets.splice(bi,1);
        enemies.splice(ei,1);
      }
    });
  });

  // Particles
  particles.forEach(p => {
    p.x += p.dx;
    p.y += p.dy;
    p.life--;
  });
  particles = particles.filter(p => p.life > 0);

  // Level progression
  if (bulletsLeft <= 0) {
    level++;
    bulletsLeft = 10 + (level-1)*5;
    if (level > bestLevel) {
      bestLevel = level;
      localStorage.setItem("bestLevel", bestLevel);
    }
  }

  // Update HUD
  scoreEl.textContent = score;
  levelEl.textContent = level;
  bulletsEl.textContent = bulletsLeft;
  bestEl.textContent = bestLevel;
}

// ===== Draw =====
function draw() {
  ctx.clearRect(0,0,canvas.width,canvas.height);

  // Player
  ctx.fillStyle = "black";
  ctx.fillRect(player.x, player.y, player.w, player.h);

  // Bullets
  ctx.fillStyle = "blue";
  bullets.forEach(b => ctx.fillRect(b.x, b.y, 4, 10));

  // Enemies
  enemies.forEach(e => {
    ctx.fillStyle = e.bomb ? "black" : "green";
    ctx.beginPath();
    ctx.arc(e.x, e.y, e.size/2, 0, Math.PI*2);
    ctx.fill();
  });

  // Particles
  particles.forEach(p => {
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x, p.y, 3, 3);
  });
}

// ===== Loop =====
function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}
loop();

// ===== Game States =====
function lose() {
  gameOver = true;
  document.getElementById("overlay").classList.remove("hidden");
}

function togglePause() {
  running = !running;
  document.getElementById("pauseBtn").style.display = running ? "inline" : "none";
  document.getElementById("resumeBtn").style.display = running ? "none" : "inline";
}

// ===== Buttons =====
document.getElementById("pauseBtn").onclick = togglePause;
document.getElementById("resumeBtn").onclick = togglePause;

document.getElementById("restartBtn").onclick = () => location.reload();

document.getElementById("retryBtn").onclick = () => {
  gameOver = false;
  bulletsLeft = 10 + (level-1)*5;
  document.getElementById("overlay").classList.add("hidden");
};

document.getElementById("fullRestartBtn").onclick = () => location.reload();